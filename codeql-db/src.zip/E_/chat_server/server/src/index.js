require('dotenv').config();
const express     = require('express');
const http        = require('http');
const { Server }  = require('socket.io');
const cors        = require('cors');
const rateLimit = require('express-rate-limit');
const connectDB   = require('./config/db');
const setupSocket = require('./socket');

const app    = express();
const server = http.createServer(app);

const clientOrigins = process.env.CLIENT_URL
  ? process.env.CLIENT_URL.split(',').map(url => url.trim())
  : [];

// Khởi tạo Socket.io
const io = new Server(server, {
  cors: { origin: clientOrigins, methods: ['GET', 'POST'], credentials: true },
});

app.set('socketio', io);

// Kết nối MongoDB
connectDB();

// Cấu hình Rate Limiting cho API
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 phút
  max: 300, // Tối đa 300 requests từ mỗi IP trong 15 phút
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Quá nhiều yêu cầu từ IP này, vui lòng thử lại sau.' },
});

// Middleware
app.use(cors({ origin: clientOrigins, credentials: true }));
app.use(express.json());
app.use('/api', apiLimiter);

// Routes — chỉ đăng ký 1 lần, trước server.listen()
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/rooms',    require('./routes/rooms'));
app.use('/api/friends',  require('./routes/friends'));
app.use('/api/reports',  require('./routes/report'));
app.use('/api/security', require('./routes/security'));

app.get('/', (req, res) => {
  res.json({ message: '🚀 Chat server đang chạy!' });
});

// Setup WebSocket
setupSocket(io);

// Khởi động server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server chạy tại http://localhost:${PORT}`);
});